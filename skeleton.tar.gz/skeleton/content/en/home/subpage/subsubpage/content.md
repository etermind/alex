---
template: simple.htm
---
This is a simple subpage inside a subpage!
