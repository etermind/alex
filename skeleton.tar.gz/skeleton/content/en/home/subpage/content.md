---
template: simple.htm
---
This is a simple subpage

```ts
# Highlighting

const t = 'OK';

function add(a, b) {
    return a + b;
}
```
