---
template: simple.htm
---
C'est une simple sous-page

```ts
# Highlighting
const t = 'OK';
```
